const ROUTES = {
  HOME: '/app',
  AUTH: '/app/auth',
  PROFILE_EDIT: '/app/profile/edit',
}

export default ROUTES
