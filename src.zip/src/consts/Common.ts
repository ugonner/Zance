export const DEFAULT_PLACEHOLDER_IMAGE = '/images/default-image-placeholder.webp'
